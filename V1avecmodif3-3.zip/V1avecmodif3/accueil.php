<!DOCTYPE html>
<html lang="fr">
  <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>Document</title>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <link rel="stylesheet" href="css/stylesheet.css">
  </head>

<body>
  <header class ="navbar navbar-expand flex-column flex-md-row bd-navbar navbar-default">
    <div class="container">
      <div class="navbar-header">
        <a class="navbar-brand" href="#"><img src="img/logo1.png" alt="logo-bank" size="20px"></a>  
      </div>
      <ul class="nav navbar-nav">
                    <li><a href="offre.html">Notre offre</a></li>
                    <li><a href="tarif.html">Nos tarifs</a></li>
                    <li><a href="support.html">Support</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
                    <li><a href="inscription.php">Ouvrir un compte courant</a></li>
                    <li><a href="login.php">Déjà client ? </a></li>
      </ul>
      
      
      </ul>
      
    </div>   
  </header>





</body>
</html>