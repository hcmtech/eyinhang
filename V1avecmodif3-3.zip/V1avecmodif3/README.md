# eyinhang

Créer un dossier "controllers" dans le "www"
Glisser déposer le fichier "authController" 
  Dans ce fichier, changer le mot de passe si besoin
